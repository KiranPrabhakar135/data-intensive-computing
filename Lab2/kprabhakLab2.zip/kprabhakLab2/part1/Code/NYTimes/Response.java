package NYTimes;

import java.util.ArrayList;
import java.util.List;

public class Response {
    public List<Docs> docs = new ArrayList<Docs>();
    Metadata meta;
//    public Metadata getMeta() {
//        return meta;
//    }
//    public void setMeta(Metadata metaObject) {
//        this.meta = metaObject;
//    }
}